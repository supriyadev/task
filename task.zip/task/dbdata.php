<?php
$conn=mysqli_connect('localhost','root','','demo');

if (isset($_POST['id'])) {
	$id=$_POST['id'];
	 $sql="select * from member where id='$id'";
          $result=mysqli_query($conn,$sql);
  while ($row=mysqli_fetch_assoc($result)) {
                $fname=$row['fname'];
                $lname=$row['lname'];
                $email=$row['email'];

               ?>

             <form action="" method="post">
             <div class="form-group">
             <input type="hidden" name="idata" value="<?php echo $row['id']; ?>">
      <label for="email">Firstname:</label>
      <input type="text" class="form-control" value="<?php echo $fname; ?>"  name="fname">
    </div>
      <div class="form-group">
      <label for="email">Lastname:</label>
      <input type="text" class="form-control" value="<?php echo $lname; ?>"  name="lname">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" value="<?php echo $email; ?>" name="email">
    </div>
    
   
               <button type="submit" name="Update" class="btn btn-danger">Update</button>
  </form>  

<?php 
}}

if (isset($_POST['delid'])) {
	$delid=$_POST['delid'];
	
	$delsql="delete from member where id=$delid";
	
	$resultdel=mysqli_query($conn,$delsql);
	if ($resultdel) {
		echo "Record Deleted";
	}
	}
?>