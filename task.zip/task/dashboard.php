<?php
     session_start();
    if (! $_SESSION['myvar']) {
       header('location:index.php');
     }   

?>
<style type="text/css">
	.container-fluid {
     padding-right: 0px !important; 
    padding-left: 0px !important; 
}
.drp{
  padding-top: 21px;
  padding-bottom: 15px;
    line-height: 0px;
    position: relative;
    display: block;
    left: -5px;
    padding: 11px 43px;
}
.btn-primary{
      color: #151414 !important;
    background-color: #fbfbfb !important;
    border-color: #f7f7f7 !important;
        border: 0px solid transparent !important;
}
.btn-info {
    color: #fff;
    background-color: #dd574c !important;
    border-color: #dd574c !important;
    padding: 9px 13px !important;
    
    border-radius: 0px !important;
}
</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
           <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          
        </div>
        <div class="navbar-collapse collapse" style="background-color: #fbfbfb;">
          <ul class="nav navbar-nav navbar-right">
            <li><img src="icon/user.ico" width="40" height="40" 
            style="margin-right: -29px;margin-top: 8px;"></li>
            <li class="drp">
                <div class="dropdown">
    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php  echo $_SESSION['myvar']; ?>
    <span class="caret"></span></button>
    <ul class="dropdown-menu">
      <li><a href="logout.php">Sign out</a></li>
      
    </ul>
  </div>
            </li>
          </ul>
          
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar sidebar-collapse"
         style="background-color: #252323;    height: 100%;
    margin-top: 3%;width: 14.666667%;">
          <ul class="nav nav-sidebar">
          <div class="col-md-2">
            <img src="icon/member.png" width="50" height="50" style="    margin-top: 36px;" >
          </div>
          <div class="col-md-2">
            <h4 style="color: white;    margin-top: 49px;
    margin-left: 34px;">Members</h4>
          </div>

            <li></li>
            
          </ul>
         
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main" 
        style="margin-top: -594px;height: 84%;background: whitesmoke;width: 82%;
    margin-left: 218px;">
              <div style="float: right;">
             <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="    margin-left: -77%;
    margin-top: 7px;">Add Member</button>
             </div><br><br>
            <div class="modal fade" id="myModal" role="dialog">
          <div class="modal-dialog">
    
      <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add User</h4>
        </div>
        <div class="modal-body">
           <form action="" method="post">
             <div class="form-group">
      <label for="email">Firstname:</label>
      <input type="text" class="form-control" id="email" placeholder="First name" name="fname">
    </div>
      <div class="form-group">
      <label for="email">Lastname:</label>
      <input type="text" class="form-control" id="email" placeholder="Last name" name="lname">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
    </div>
   
    <button type="submit" name="savedata" class="btn btn-danger">Add</button>
  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
          <!-- <h1 class="page-header">Dashboard</h1> -->


          <!-- <h2 class="sub-header">Section title</h2> -->
          <?php  
          $conn=mysqli_connect('localhost','root','','demo');
          $sql="select * from member";
          $result=mysqli_query($conn,$sql);

          ?>
          <div class="" style="width: 87%;margin-left: 4%;">
            <table class="table table-striped">
              <thead>
              <tr>
                             
                  <th></th>
                  <th></th>
                  <th></th>
                 
                
                
                </tr>
              </thead>
              <tbody>
                
                 <?php
              while ($row=mysqli_fetch_assoc($result)) {
                $fname=$row['fname'];
                $lname=$row['lname'];
                $email=$row['email'];

              ?>
<tr style="border: 2px solid #dddddd;">
                  <td><img src="icon/person.png" width="40" height="40"
                   style="border-radius: 50px;">&nbsp;&nbsp;<?php echo "$fname $lname";?></td>
                 
                  <td><?= $email?></td>
                  <td><a href="#" onclick="update(<?php echo $row['id']?>)"><img src="icon/edit.png" width="30" height="30"></a>  
                  <a href="#" onclick="deletedata(<?php echo $row['id']?>)"><img src="icon/delete.png" width="30" height="30"></a></td>
                  </tr>
                  <?php  }?>
                
               
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php

$conn=mysqli_connect('localhost','root','','demo');
// insert data

if (isset($_POST['savedata'])) {
  $fname=$_POST['fname'];
  $lname=$_POST['lname'];
  $email=$_POST['email'];
  $password=$_POST['password'];

  $checkdata="select email from member where email='$email'";
  $data=mysqli_query($conn,$checkdata);
  $resultdata=mysqli_num_rows($data);
  if ($resultdata>0) {
    echo "<script>alert('Email-id already Exist');</script>";
  }else{
    $query="insert into member(fname,lname,email,password)values('$fname','$lname','$email','$password')";
  $run=mysqli_query($conn,$query);
  if ($run) {
    echo "<script>alert('Succesfully Inserted Data');</script>";
    echo "<script>window.location.href = 'dashboard.php';</script>";
  }else{
    echo "<script>alert('Somthng Wrong');</script>";
    
  }
    
  }
  

}
?>
<script type="text/javascript">
  function update(id){
    var id=id;
     $.ajax({
                   type: "POST",
                   data: {'id': id},
                   datatype: "json",
                   url:'dbdata.php',
                   
                   success:function(data){
                    
                    $('.modal-body').html(data);
                     $('#update_model').modal('show');
                   }
                          
                     });
     
  }
  function deletedata(id){
    var delid=id;
     $.ajax({
                   type: "POST",
                   data: {'delid': delid},
                   datatype: "json",
                   url:'dbdata.php',
                   
                   success:function(data){
                    alert(data);
                    window.location.href = 'dashboard.php';
                   }
                          
                     });
  }
</script>
<div class="modal fade" id="update_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title" id="myModalLabel">Update Data</h4>

            </div>
            <div class="modal-body">
              
            </div>
            <div class="modal-footer">
 
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                
            </div>
        </div>
    </div>
</div>
<?php
if (isset($_POST['Update'])) {
   $fname=$_POST['fname'];
  $lname=$_POST['lname'];
  $email=$_POST['email'];
  $id=$_POST['idata'];
  $updatesql="update member set fname='$fname',lname='$lname',email='$email' where id='$id'";
  $result=mysqli_query($conn,$updatesql);
  if ($result) {
  echo "<script>alert('sucessfully Updated')</script>";
    echo "<script>window.location.href = 'dashboard.php';</script>";

  }
}
?>