<?php include 'conf.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Mini Car Inventory System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- <script type="text/javascript" href="allscript.js"></script> -->
</head>
<style>
  .logo{
    width: 45%;
    margin-right: auto;
    margin-left: auto;
  }
  .modal-header{
    padding: 10px;
  }
</style>
<body>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h3 class="text-center">Mini Car Inventory System</h3>
      <hr>
      <div class="col-md-4 text-center">
        <img src="add.png" class="img-responsive logo"><br>
        <input type="button" class="btn btn-info btn-lg btn-sm" data-toggle="modal" data-target="#myModal" value="Add Manufacturer">
        
        <!-- add manufacturer -->
         <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Manufacturer</h4>
        </div>
        <div class="modal-body">
              <h4 class="text-center display" style="color: red;display: none;"></h4>
           <form class="form-inline" action="" id="manufacturer" onsubmit="return false;">
  <div class="form-group">

    <input type="text" class="form-control btn-lg" placeholder="manufacturer name" name="manufacturer" required="">
  </div>
  

  <button type="submit" class="btn btn-info btn-md">Create</button>
  <button type="reset" class="btn btn-info reset">Reset</button>
</form> 
<br>
        </div>
       
      </div>
      
    </div>
  </div>
        <!-- end manufacturer -->
      </div>

      <!-- model addition -->
            <div class="col-md-4 text-center">
        <img src="add.png" class="img-responsive logo"><br>
        <input type="button" class="btn btn-info btn-lg btn-sm" onclick="adddata()" data-toggle="modal" data-target="#myModal1" value="Add Model">
        
        <!-- add manufacturer -->
         <!-- Modal -->
    <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Model</h4>
        </div>
        <div class="modal-body" id="setdata">
              
        
          

        </div>
       
      </div>
      
    </div>
  </div>
        <!-- end manufacturer -->
      </div>      
      <!-- display -->
                 <div class="col-md-4 text-center">
        <img src="display.png" class="img-responsive logo"><br>
        <input type="button" class="btn btn-info btn-lg btn-sm" onclick="displaydata()" data-toggle="modal" data-target="#myModal2" value="View data">
        
        <!-- add manufacturer -->
         <!-- Modal -->
    <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">All Records</h4>
        </div>
        <div class="modal-body" id="getdata">
        </div>
       
      </div>
      
    </div>
  </div>
        <!-- end manufacturer -->
      </div>     </div>
  </div>
</div>

</body>
</html>
<script>

  // add data
function adddata(){
  $.ajax({
    type:'post',
    url:'ajaxfile/popupdata.php',
    success:function(data){
      //alert(data);
      $('#setdata').html(data);
       
    }
});
}
function displaydata(){
  $.ajax({
    type:'post',
    url:'ajaxfile/display.php',
    success:function(data){
      //alert(data);
      $('#getdata').html(data);
       
    }
});
}
$(document).ready(function(){
$('#manufacturer').submit(function(){
var namedata=$(this).serialize();
//alert(name);
$.ajax({
    type:'post',
    url:'ajaxfile/createmanu.php',
    data:namedata,
    success:function(data){
      $('.display').show().text(data);
         // alert(data);
        $('.reset').trigger('click'); 
    }
});
});


    });

  // delete record
      function deletedata(delid){
        $.ajax({
    type:'post',
    url:'ajaxfile/sold.php',
    data:{'delid':delid},
    success:function(data){
      // alert(data);
      if (data==1) {

        $('.hide'+delid).hide();
         
    }else{
      alert("error");
    }
  }
});
      }
</script>