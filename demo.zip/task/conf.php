<?php
$conn=mysqli_connect('localhost','root','','task');
if ($conn) {
	//echo "connection established";
}else{
	//echo "connection lost";
}
 ?>
