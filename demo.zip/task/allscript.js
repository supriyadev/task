$(document).ready(function(){
$('#manufacturer').submit(function(){
alert("hii");
});
});