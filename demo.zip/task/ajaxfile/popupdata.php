   <?php include '../conf.php'; ?>
   <form class="form-inline" method="POST" action="ajaxfile/adddata.php" id="addmodel" 
           enctype="multipart/form-data" onsubmit="return false;">
                  <div class="form-group">
                  <input type="text" class="form-control" name="modelname" placeholder="enter model name">
                  </div>

                  <div class="form-group">
                  <select class="form-control" id="sel1" name="manuname">
                  <option selected="">Select Manufacturer</option>
                  <?php $get="SELECT * FROM manufacturer";
                  $fetch=mysqli_query($conn,$get);
                  while($row=mysqli_fetch_assoc($fetch)) { ?>
                  <option value="<?= $row['name']; ?>"><?= $row['name']; ?></option>   
                  <?php } ?>
                  </select>
                  </div> <br><br>
                  <div class="form-group">
                  <input type="text" class="form-control" placeholder="color" name="color">
                  </div>
                  <div class="form-group">
                  <input type="text" class="form-control" placeholder="manufacturing year" name="year">
                  </div>
                  <div class="form-group">
                  <input type="text" class="form-control" placeholder="registration number" name="number">
                  </div>
                  <br><br>
                  <div class="form-group">
                  <label>image 1</label>
                  <input type="file" name="img1" class="ImageBrowse">
                  </div>
                  <div class="form-group">
                  <label>image 1</label>
                  <input type="file" name="img2" class="ImageBrowse">
                  </div><br><br>
                  <button type="submit" class="btn btn-info">Submit</button>
                  <button type="reset" class="btn btn-info reset">Reset</button>

          </form> 
          <br>

          <script type="text/javascript">
                $(document).ready(function(){
                  // modeldata
    $('#addmodel').on('submit',(function(e) {
        e.preventDefault();
        $.ajax({
        url: $(this).attr('action'), 
        type: "POST",             
        data: new FormData(this), 
        contentType: false,       
        cache: false,             
        processData:false,        
        success: function(data)   
        {   alert(data);
        $('.reset').trigger('click'); }
        }); 
    }));
    });
              
          </script>