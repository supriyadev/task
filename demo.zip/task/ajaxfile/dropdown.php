<?php include '../conf.php'; ?>
<option selected="">Select Manufacturer</option>
                  <?php $get="SELECT * FROM manufacturer";
                  $fetch=mysqli_query($conn,$get);
                  while($row=mysqli_fetch_assoc($fetch)) { ?>
                  <option value="<?= $row['name']; ?>"><?= $row['name']; ?></option>   
                  <?php } ?>