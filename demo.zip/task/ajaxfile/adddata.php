<?php 
include '../conf.php';
if (isset($_POST['modelname'])) {
	$modelname=$_POST['modelname'];
	$manuname=$_POST['manuname'];
	$color=$_POST['color'];
	$year=$_POST['year'];
	$number=$_POST['number'];
	$img1=$_FILES['img1']['name'];
	$img2=$_FILES['img2']['name'];
	$sourcePath1 = $_FILES['img1']['tmp_name'];
	$sourcePath2 = $_FILES['img2']['tmp_name'];
	$targetPath = "../modelimage/".$_FILES['img1']['name']; 
	move_uploaded_file($sourcePath1,$targetPath) ;
	$targetPath = "../modelimage/".$_FILES['img2']['name']; 
	move_uploaded_file($sourcePath2,$targetPath) ;
	$add="INSERT INTO modeldata(model_name,name,color,year_data,register_no,img1,img2)VALUES('$modelname','$manuname','$color','$year','$number','$img1','$img2')";
	
	$run=mysqli_query($conn,$add);
	if ($run) {
		echo "record successfully saved";
	}else{
		echo "error";
	}

}
?>