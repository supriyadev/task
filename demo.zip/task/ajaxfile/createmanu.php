<?php
include '../conf.php';
if (isset($_POST['manufacturer'])) {
 $name=$_POST['manufacturer'];	
 $checkquery="SELECT * FROM manufacturer WHERE name='$name'";
 $check=mysqli_query($conn,$checkquery);
 if (mysqli_num_rows($check)>0) {
 	echo "Record already exist";
 }else{
	$query="INSERT INTO manufacturer(name)VALUES('$name')";
 	$run=mysqli_query($conn,$query);
 	if($run) {
 	echo "Record sucessfully added";
 	}else{
 	echo "error";
 	}
}
 }
 
  ?>