 <?php include '../conf.php'; ?>
 <table class="table table-bordered">
    <thead>
      <tr>
        <th>Model name</th>
        <th>Manufacturer</th>
        <th>Color</th>
        <th>Year</th>
        <th>Registration Number</th>
        <th>Image 1</th>
        <th>Image 2</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
             <?php $data="SELECT * FROM modeldata";
        $rundata=mysqli_query($conn,$data);
        while ($rowdata=mysqli_fetch_assoc($rundata)) { ?>
        <tr class="hide<?= $rowdata['model_id'] ?>">
        <td><?= $rowdata['model_name'] ?></td>
        <td><?= $rowdata['name'] ?></td>
        <td><?= $rowdata['color'] ?></td>
        <td><?= $rowdata['year_data'] ?></td>
        <td><?= $rowdata['register_no'] ?></td>
        <td><img src="modelimage/<?= $rowdata['img1'] ?>" class="img-responsive"></td>
        <td><img src="modelimage/<?= $rowdata['img2'] ?>" class="img-responsive"></td>
        <td><button class="btn btn-danger" onclick="deletedata('<?= $rowdata['model_id'] ?>')">Sold</button></td>
      </tr>
        <?php } ?>   

    </tbody>
  </table>

