<?php
include '../conf.php';
if (isset($_POST['delid'])) {
 	$delid=$_POST['delid'];

 	$del="DELETE FROM modeldata WHERE model_id='$delid'";
 	$remove=mysqli_query($conn,$del);
 	if ($remove) {
 		echo 1;
 	}else{
 		echo 2;
 	}
 } ?>